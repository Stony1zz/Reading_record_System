CREATE VIEW Read_Card
AS
SELECT Readbook.Uno,Ustudent.Uname,Book.Bno,Book.Bname,Readbook.Rpage,Readbook.Rpecent
FROM Ustudent,Readbook,Book
WHERE Readbook.Uno=Ustudent.Uno AND Readbook.Bno=Book.Bno;
GO

