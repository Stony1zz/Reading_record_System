CREATE VIEW HardReader(Uname,Bpiont)
AS SELECT top 100 percent  Ustudent.Uname,SUM(Readbook.Rpage)as BIG
FROM Ustudent,Readbook
GROUP BY Ustudent.Uname,Readbook.Uno,Ustudent.Uno
HAVING Ustudent.Uno=Readbook.Uno
GO

