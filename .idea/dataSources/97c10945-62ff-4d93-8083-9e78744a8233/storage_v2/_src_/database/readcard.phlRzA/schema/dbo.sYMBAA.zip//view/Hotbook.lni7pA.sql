CREATE VIEW Hotbook(Bname,Bpiont)
AS SELECT top 100 percent  Book.Bname,SUM(Readbook.Rpage)as BIG
FROM Book,Readbook
GROUP BY Book.Bname,Book.Bno,Readbook.Bno
HAVING Book.Bno=Readbook.Bno
GO

